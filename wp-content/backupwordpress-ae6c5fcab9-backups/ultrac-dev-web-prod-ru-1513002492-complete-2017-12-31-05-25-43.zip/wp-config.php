<?php
/**
 * Основные параметры WordPress.
 *
 * Этот файл содержит следующие параметры: настройки MySQL, префикс таблиц,
 * секретные ключи и ABSPATH. Дополнительную информацию можно найти на странице
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Кодекса. Настройки MySQL можно узнать у хостинг-провайдера.
 *
 * Этот файл используется скриптом для создания wp-config.php в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать этот файл
 * с именем "wp-config.php" и заполнить значения вручную.
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'testbase');

/** Имя пользователя MySQL */
define('DB_USER', 'john');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'aJLssbPAUNcN4bVc');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '~JFc3-fR/kW(TN[4wO|#6LfXFE:V*st.Jjoj7`/rrI+@S`/?~nZ<8va&6<19fQ*F');
define('SECURE_AUTH_KEY',  'aG~]ITrSB!IKK[))yZ6f6]zACDZewRkLIHi/J[hQa-?rne#P5AiKw^nwe-y8$d*u');
define('LOGGED_IN_KEY',    'w_3lt(#?moa?@]5qN@];1gYW5&2B0#h^#VD>3BdL36C)K?dMr>}!v<`8].U)4zE#');
define('NONCE_KEY',        'EZM:sG[M|_/M7SWhBCL2~ePCJg53,)>~jsO;p@[m6uu1M)B7%<oR,91cy[F2go)(');
define('AUTH_SALT',        'JB #lp[IV4EI>A| _L(S$jp b&O,z@ MQPd.<!nq9`}AbJW3<$zH[WrKooH<9jf{');
define('SECURE_AUTH_SALT', '~AwFQa_q~?-e81wN4!%)/[$!JDbeR+-X8Q)}X&LU-(P%AxW-fC3$T|>}-3KgxW$v');
define('LOGGED_IN_SALT',   'x|KCKfnLla^lNDB-x)!]>CAyg3D#!JHt^k.ai8Xcw>De+:a)5SzN]Gz}E@-#{NvL');
define('NONCE_SALT',       '8{;w4Pp03!Z;Skt%}3w94K~0+l}]QV)NX(>`4#zJP+$!*uci[)DO>md_!{+;{Bgr');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
