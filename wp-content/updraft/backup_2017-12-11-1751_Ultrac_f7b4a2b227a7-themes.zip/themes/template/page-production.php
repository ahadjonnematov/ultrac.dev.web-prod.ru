<?php
/**
Template Name: Продукция
 */

include 'header.php'; ?>

<section class="production inner_page">
	<div class="production_header">
		<div class="center_cnt">
			<div class="production_element">MgO</div>
			<div class="production_head_cnt">
				<div class="phc_cat">Продукция</div>
				<h1>Производим и продаем оксид магния</h1>
				<div class="relevant_products">
					<a href="/">Оксид магния высокочистый</a>
					<a href="/">Оксид магния низкой чистоты</a>
				</div>
			</div>
		</div>
	</div>

	<div class="production_body">
		<div class="center_cnt">
			<h2>Оксид магния высокочистый</h2>
			<div class="production_cnt">
				<div class="production_cnt_desc">
					<p>Химическое соединение с формулой MgO, белые кристаллы, нерастворимые в воде, пожаро- и взрывобезопасен.</p>

					<p>Основная форма — минерал периклаз. Активно используется в строй материалах, в металлургии, при повышении термических свойств стали.</p>

					<h3>Химические показатели нашей продукции</h3>

					<div class="table_wrap">
						<table>
							<thead>
								<tr>
									<td>Заголовок столбца</td>
									<td>ГОСТ</td>
									<td>Результат Ultra-C</td>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Массовая доля оксида магния</td>
									<td>97%</td>
									<td>97%</td>
								</tr>
								<tr>
									<td>Массовая доля нерастворимых веществ</td>
									<td>0.05%</td>
									<td>0.05%</td>
								</tr>
								<tr>
									<td>Массовая доля растворимых в воде веществ</td>
									<td>0.05%</td>
									<td>0.05%</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
				<div class="production_cnt_sidebar">
					<a href="/">Брошюра о продукции компании (Product data sheet)</a>
					<a href="/">Презентация компании</a>
					<div class="ask_sample">Запросить образец продукции</div>
				</div>
			</div>
		</div>
	</div>

	<div class="production_body gray_bg">
		<div class="center_cnt">
			<h2>Оксид магния высокочистый</h2>
			<div class="production_cnt">
				<div class="production_cnt_desc">
					<p>Химическое соединение с формулой MgO, белые кристаллы, нерастворимые в воде, пожаро- и взрывобезопасен.</p>

					<p>Основная форма — минерал периклаз. Активно используется в строй материалах, в металлургии, при повышении термических свойств стали.</p>

					<h3>Химические показатели нашей продукции</h3>

					<div class="table_wrap">
						<table>
							<thead>
								<tr>
									<td>Заголовок столбца</td>
									<td>ГОСТ</td>
									<td>Результат Ultra-C</td>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Массовая доля оксида магния</td>
									<td>97%</td>
									<td>97%</td>
								</tr>
								<tr>
									<td>Массовая доля нерастворимых веществ</td>
									<td>0.05%</td>
									<td>0.05%</td>
								</tr>
								<tr>
									<td>Массовая доля растворимых в воде веществ</td>
									<td>0.05%</td>
									<td>0.05%</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
				<div class="production_cnt_sidebar">
					<a href="/">Брошюра о продукции компании (Product data sheet)</a>
					<a href="/">Презентация компании</a>
					<div class="ask_sample">Запросить образец продукции</div>
				</div>
			</div>
		</div>
	</div>

	<div class="fields_of_use">
		<div class="center_cnt">
			<h2>Оксид магния высокочистый</h2>
			
			<div class="fields_of_use_list">
				<div class="fields_of_use_item" style="background-image: url(/wp-content/themes/template/img/fou_item.jpg);"><span>Трансформаторная<br> сталь</span></div>
				<div class="fields_of_use_item" style="background-image: url(/wp-content/themes/template/img/fou_item.jpg);"><span>Трансформаторная<br> сталь</span></div>
				<div class="fields_of_use_item" style="background-image: url(/wp-content/themes/template/img/fou_item.jpg);"><span>Трансформаторная<br> сталь</span></div>
			</div>
		</div>
	</div>	
</section>

<section class="main_field inner_page">
	<div class="center_cnt">
		<div class="section_title">Месторождение</div>
		
		<div class="main_field_desc">
			<div class="mfd_title">Описание</div>
			<p>Разработка ведется открытым способом на базе богатейшего Баженовского месторождения, разведанных запасов которого хватит более чем на 150 лет.</p>
			<p>Месторождение расположено в 60 км к северо-востоку от г. Екатеринбурга.</p>
			<p>Оно является одним из крупнейших в мире промышленных месторождений минералов. Протяженность карьера составляет 8 км, ширина карьера 2,5 км, глубина 350 м. Общая площадь, занятая горными работами, составляет 40 км<sup>2</sup>.</p>
		</div>

		<div class="main_field_features_list">
			<div class="mff_item">
				<div class="mff_item_title">Крупнейший карьер в Евразии</div>
				Запасов хватит на 150 лет разработки
			</div>

			<div class="mff_item">
				<div class="mff_item_title">Масштабные работы</div>
				Работы ведутся на площади 40 кв.км. В 2017 году. Протяженность карьера — 8 км, ширина — 2,5 км, глубина 350м
			</div>

			<div class="mff_item">
				<div class="mff_item_title">Производство на Урале</div>
				160 километров от Екатеринбурга
			</div>
		</div>
	</div>
	<div class="main_field_img" style="background-image: url(/wp-content/themes/template/img/main_field_bg.jpg)"></div>
</section>

<?php include 'footer.php'; ?>
