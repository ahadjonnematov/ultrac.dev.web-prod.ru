<?php
/**
 * Шаблон подвала (footer.php)
 * @package WordPress
 * @subpackage your-clean-template
 */
?>
<?$pageContact = get_page(5,"ARRAY_A");?>
	<footer>
		<div class="center_cnt">

			<div>© <?php echo date('Y'); ?><?bloginfo('name'); ?></div>

			<div>
				<?=get_field_object("ReceptionFax",$pageContact["ID"])["label"];?>
                <br>
				<a href="tel:+7(343)255-58-58"><?=get_post_custom($pageContact["ID"] )[" ReceptionFax"][0]?></a>
			</div>

			<div>
				<?=get_field_object("email",$pageContact["ID"])["label"];?><br>
				<a href="mailto:<?=get_post_custom($pageContact["ID"] )["email"][0]?>"><?=get_post_custom($pageContact["ID"] )["email"][0]?></a>
			</div>

			<div>
				<img src="http://ultrac.dev.web-prod.ru/wp-content/uploads/2017/12/ft_logo.png" alt="<?bloginfo('name'); ?>">
			</div>
		</div>
	</footer>

<?php wp_footer(); ?>


<div class="overlay">

		<div class="modal_window">
			<div class="modal_close"></div>
			<div class="form_title">Запрос образца продукции</div>
            <a></a>
                <?
                    $a=["select menu-978","Оксид магния","Гидроксид магния"];
                    echo "<pre>";
                    print_r( $a );
                    echo "</pre>";
                    //ко ми ,ха

                    //exit; // зато н просто болошанда ки м дизе хамун ба нишон надосос
                // ё дигар страницанда
                ?>

<a href="#" class="eModal-">Open Modal</a>
			<form class="feedback_form">
				<div class="ff_block">

					<label for="ff_name">Интересующее химическое соединение</label>
					<div class="custom_select">
						<div class="current_opt">Оксид магния</div>
						<div class="opt_list">
                            <div class="opt_item" data-opt="1">Оксид магния</div>
                            <div class="opt_item" data-opt="2">Гидроксид магния</div>
                            <div class="opt_item" data-opt="3">Сульфат магния</div>
                            <div class="opt_item" data-opt="4">Магнезия Альба</div>
                            <div class="opt_item" data-opt="5">Аморфный кремнозем</div>
                            <div class="opt_item" data-opt="6">Водорастворимый гидросиликат калия</div>
                        </div>
                        <div class="opt_list">
							<div class="opt_item" data-opt="1">[select menu-978 "Оксид магния" "Гидроксид магния"]</div>

						</div>
					</div>
				</div>
				<div class="ff_block">
					<label for="ff_name"><?=["text text-372","Как вас зовут"]?></label>
					<input type="text" id="ff_name">
					<span class="ff_err">заполните это поле!</span>
				</div>
				<div class="ff_block">
					<label for="ff_phone">Телефона</label>
					<input type="text" id="ff_phone">
					<span class="ff_err">заполните это поле!</span>
				</div>
				<div class="ff_block">
					<label for="ff_mail">Электронная почта</label>
					<input type="text" id="ff_mail">
					<span class="ff_err">заполните это поле!</span>
				</div>
				<div class="ff_block">
					<label for="ff_company">Название компании</label>
					<input type="text" id="ff_company">
					<span class="ff_err">заполните это поле!</span>
				</div>
				<div class="ff_footer">
					<input type="submit" value="Отправить" class="ff_send">
					<p>Нажимая эту кнопку, вы соглашаетесь с <a href="/">политикой обработки персональных данных</a></p>
				</div>
			</form>
			<div class="ff_ty">Ваш запрос успешно отправлен!</div>
		</div>
	</div>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/scripts.js"></script>

</body>
</html>