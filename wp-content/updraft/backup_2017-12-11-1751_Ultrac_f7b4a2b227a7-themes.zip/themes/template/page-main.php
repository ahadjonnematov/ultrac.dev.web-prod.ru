<?php
/**
Template Name: Главная
 */

include 'header.php'; ?>

<section class="main_company_info">
	<!--
	    <source src="/wp-content/themes/template/video/main_page_video.mp4">
	    <source src="/wp-content/themes/template/video/main_page_video.webm" type="video/webm">
	-->

    <video class="mp_screen_one_video" preload="auto" loop  autoplay muted>

		<source src="<?=get_field('mp4Video');?>">
		<source src="<?=get_field('webmVideo');?> type="video/webm">
	</video>

	<div class="center_cnt">
		<div class="mci_desc">
            <?=get_field('descriptionVideo');?>
		</div>



		<div class="mci_features">
            <?
                if ( have_posts() ) :
                      $as=query_posts( array( 'category_name'=>'advantages','orderby' => 'ID', 'order' => 'ASC' ) );
                if( count($as)==3 ):
                      while (have_posts()) : the_post();
            ?>

			<div class="mci_features_item">
            	<div class="mci_features_title"><?php the_title(); ?></div>
				<p><?the_content(); ?></p>
			</div>

           <?  endwhile;
                endif;
                endif;
                wp_reset_query();
            ?>
	    </div>
</section>

<section class="main_products">
	<div class="center_cnt">
		<div class="section_title"><? echo get_cat_name(8);?></div>

		<div class="main_products_list">




            <?
                if ( have_posts() ) :
                      query_posts( array( 'category_name'=>'production' ) );

                      while (have_posts()) : the_post();
            ?>
			<a href="<? echo get_permalink(); ?>" class="mpl_item">
				<span><? the_field( "description" ); ?></span>
                <p><? the_title(); ?> </p>
			</a>
             <?  endwhile;
                endif;

                wp_reset_query();
            ?>


		</div>
	</div>
</section>

<section class="main_press">
	<div class="center_cnt">
		<div class="section_title"><? echo get_cat_name(7);?></div>

		<div class="main_press_list">
			<?
                $postDescription = wp_get_recent_posts( array("cat"=>7,'orderby' => 'ID','order' => 'DESC','showposts' => '1') );
                foreach( $postDescription as $k=>$v ):
                   /* echo "<pre>";print_r( $v );echo "</pre>";exit;*/

                    $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $v["ID"] )  );
                    $src = wp_get_attachment_image_src( get_post_thumbnail_id( $v["ID"] ), 'thumbnail_size' );
            ?>
                    <a href="<?=$v["guid"];?>" class="mpress_item_big" style="background-image: url(<?=$src[0]?>);">
                        <span class="mpress_item_big_date"><?=date("Y-m-d",strtotime( $v["post_date"] )) ?></span>
                        <span><?=$v["post_title"]; ?></span>
                    </a>
            <?
                endforeach;

            ?>

			<div class="mpress_items_small">
                <? if ( have_posts() ) :
                    $a=query_posts( array( 'category_name'=>'news','orderby' => 'ID', 'order' => 'DESC','showposts' => '3', ) );

                    while( have_posts() ) : the_post();
                ?>
                        <a href="<? echo get_permalink(); ?>" class="mpress_item">
                            <span><? the_time('j F Y'); ?></span>
                            <p><? the_title(); ?></p>
                        </a>
                <? endwhile;
                 endif;

                 wp_reset_query();
                 ?>
                     


				<a href="/news" class="mpl_btn">Все новости</a>
			</div>
		</div>
	</div>
</section>

<section class="main_app_area">
	<div class="app_area_bgs">
		<div style="background-image: url(/wp-content/themes/template/img/app_area_bg_1.jpg)"></div>
		<div style="background-image: url(/wp-content/themes/template/img/app_area_bg_2.jpg)"></div>
		<div style="background-image: url(/wp-content/themes/template/img/app_area_bg_3.jpg)"></div>
	</div>

	<div class="center_cnt">
		<div class="section_title">Сферы применения наших соединений</div>

		<div class="app_areas_list">
            	  <?
                if ( have_posts() ) :
                      query_posts( array( 'category_name'=>'sferyi-primeneniya','orderby' => 'ID', 'order' => 'ASC' ) );

                      while (have_posts()) : the_post();
            ?>
               <div class="aal_item">
				    <div class="aal_item_title"><span><?php the_title(); ?></span></div>
				<div class="aal_item_desc">
					<p><?the_content(); ?></p>
				</div>
			</div>
            <?  endwhile;
            endif;

            wp_reset_query();
            ?>

		</div>
	</div>
</section>

<section class="main_field">
	<div class="center_cnt">
		<div class="section_title"><? echo get_cat_name(4);?></div>




		<div class="main_field_desc">
            <?
                if ( have_posts() ) :
                      query_posts( array( 'category_name'=>'description','orderby' => 'ID', 'order' => 'ASC' ) );

                      while (have_posts()) : the_post();
            ?>
			<div class="mfd_title"><?php the_title(); ?></div>
			<p><?the_content(); ?></p>
            <?  endwhile;
                endif;

                wp_reset_query();
            ?>
		</div>

		<div class="main_field_features_list">
             <?
                if ( have_posts() ) :
                      $as=query_posts( array( 'category_name'=>'advantages','orderby' => 'ID', 'order' => 'ASC' ) );
                if( count($as)==3 ):
                      while (have_posts()) : the_post();
            ?>

			<div class="mff_item">
            	<div class="mff_item_title"><?php the_title(); ?></div>
				<p><?the_content(); ?></p>
			</div>

           <?  endwhile;
                endif;
                endif;
                wp_reset_query();
            ?>

		</div>
	</div>



   <?
        $postDescription = wp_get_recent_posts( array("cat"=>5) );
         foreach( $postDescription as $k=>$v ){
            $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $v["ID"] )  );
            $src = wp_get_attachment_image_src( get_post_thumbnail_id( $v["ID"] ), 'thumbnail_size' );
            echo "<div class='main_field_img' style='background: url({$src[0]})'></div>";
         }

    ?>

</section>

<section class="main_company_desc">
	<div class="center_cnt">
		<div class="section_title">Компания Ultra-C</div>

		<div class="mcd_text">
			<p>Из наиболее ценных и важных для современной техники металлов лишь немногие содержатся в земной коре в больших количествах: алюминий (8,9 %), железо (4,65 %), магний (2,1 %), титан (0,63 %). Природные ресурсы некоторых весьма важных металлов измеряются сотыми и даже тысячными долями процента. Особенно бедна природа благородными и редкими металлами.</p>

			<p>Производство и потребление металлов в мире постоянно растёт. За последние 20 лет ежегодное мировое потребление металлов и мировой металлофонд удвоились и составляют, соответственно, около 800 млн тонн и около 8 млрд тонн. Изготовленная с использованием черных и цветных металлов доля продукции в настоящее время составляет 72—74 % валового национального продукта государств. Металлы в XXI веке остаются основными конструкционными материалами, так как по своим свойствам, экономичности производства и потребления не имеют себе равных в большинстве сфер применения.</p>
		</div>

		<div class="mcd_docs">
			<a href="/">Брошюра о продукции компании (Product data sheet)</a>
			<a href="/">Презентация компании</a>
			<div class="mcd_sample_btn">Запросить образец продукции</div>
		</div>
	</div>
</section>

<section class="main_clients">
	<div class="center_cnt">
		<div class="section_title">Клиенты</div>

		<div class="main_clients_list">



        <?
            if ( have_posts() ) :
                 query_posts("cat=9");
                 while( have_posts() ) : the_post();

	    ?>

			<div class="mcl_item">
                 <? the_post_thumbnail() ?>
			</div>
         <?  endwhile;
                 endif;

                 wp_reset_query();
                 ?>


		</div>
	</div>
</section>

<?php include 'footer.php'; ?>
