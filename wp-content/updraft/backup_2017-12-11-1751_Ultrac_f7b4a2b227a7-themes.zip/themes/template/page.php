<?php
/**
 * Шаблон обычной страницы (page.php)
 * @package WordPress
 * @subpackage your-clean-template
 */
get_header(); ?>

<section class="about inner_page">
	<div class="center_cnt">
		<h1>Обычная страница</h1>

		<div class="about_body">
			<div class="about_cnt">
				<p>ITinvest специализируется только на клиентском бизнесе. В группе нет банка, а с начала 2015 года брокерский бизнес стал исключительной деятельностью ITinvest. </p>

				<p>Компания не проводит собственные операции для предотвращения даже гипотетически возможного конфликта интересов с клиентскими операциями на рынке. Это позволяет клиентам быть более уверенными в надежности и стабильности брокера.</p>

				<h3>Откройте брокерский счет заголовок H3</h3>

				<p>ITinvest специализируется только на клиентском бизнесе. В группе нет банка, а с начала 2015 года брокерский бизнес стал исключительной деятельностью ITinvest. </p>

				<p>Компания не проводит собственные операции для предотвращения даже гипотетически возможного конфликта интересов с клиентскими операциями на рынке. Это позволяет клиентам быть более уверенными в надежности и стабильности брокера.</p>
				
				<ul>	
				    <li>основные сведения</li>
				    <li>агломерации-миллионеры</li>
				    <li>предыстория</li>
				</ul>

				<ol>	
				    <li>основные сведения</li>
				    <li>агломерации-миллионеры</li>
				    <li>предыстория</li>
				</ol>

				<div class="table_wrap">
					<table>
						<thead>
							<tr>
								<td>Заголовок столбца</td>
								<td>ГОСТ</td>
								<td>Результат Ultra-C</td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Массовая доля оксида магния</td>
								<td>97%</td>
								<td>97%</td>
							</tr>
							<tr>
								<td>Массовая доля нерастворимых веществ</td>
								<td>0.05%</td>
								<td>0.05%</td>
							</tr>
							<tr>
								<td>Массовая доля растворимых в воде веществ</td>
								<td>0.05%</td>
								<td>0.05%</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div class="content_slider">
					<div class="content_slider_slides">					
						<div class="cs_slide" style="background-image: url(/wp-content/themes/template/img/csc_slide.jpg);" data-csslidenum="1"></div>
						<div class="cs_slide" style="background-image: url(/wp-content/themes/template/img/csc_slide.jpg);" data-csslidenum="2"></div>
						<div class="cs_slide" style="background-image: url(/wp-content/themes/template/img/csc_slide.jpg);" data-csslidenum="3"></div>
						<div class="cs_slide" style="background-image: url(/wp-content/themes/template/img/csc_slide.jpg);" data-csslidenum="4"></div>
						<div class="cs_slide" style="background-image: url(/wp-content/themes/template/img/csc_slide.jpg);" data-csslidenum="5"></div>
						<div class="cs_slide" style="background-image: url(/wp-content/themes/template/img/csc_slide.jpg);" data-csslidenum="6"></div>
					</div>
					<div class="content_slider_controls">
						<div class="csc_prev"></div>
						<div class="csc_counter">
							<span class="csc_current">1</span>/<span class="csc_total"></span>
						</div>
						<div class="csc_next"></div>
					</div>
				</div>
			</div>

			<div class="production_cnt_sidebar">
				<a href="/">Брошюра о продукции компании (Product data sheet)</a>
				<a href="/">Презентация компании</a>
				<div class="ask_sample">Запросить образец продукции</div>
			</div>
		</div>

	</div>
</section>

<?php get_footer(); ?>