<?php
/**
 * Страница 404 ошибки (404.php)
 * @package WordPress
 * @subpackage your-clean-template
 */
get_header(); ?>

<section class="not_found inner_page">
	<div class="center_cnt">
		<h1>404</h1>
		<div class="not_found_subtitle">Страница не найдена</div>
		<p>Неправильно набран адрес, или такой страницы на сайте больше не существует.</p>
		<p>Перейдите на <a href="/">главную страницу</a>.</p>
	</div>
</section>

<?php get_footer(); ?>