<?php
/**
Template Name: Новости
 */

include 'header.php'; ?>

<section class="news inner_page">
	<div class="center_cnt">
		<h1>Пресс-центр</h1>

		<div class="press_list">
			<div class="press_list_item">
				<div class="pli_date">25 июля</div>
				<div class="pli_cnt">
					<div class="pli_cat">Новость</div>
					<div class="pli_img">
						<img src="/wp-content/themes/template/img/pli_img.jpg" alt="">
					</div>
					<a class="pli_title" href="/">Запуск нового участка раработки: объем добычи вырастет в два раза (без фото)</a>
					<div class="pli_anonce">
						Химическое соединение с формулой MgO, белые кристаллы, нерастворимые в воде, пожаро- и взрывобезопасен. Основная форма — минерал периклаз. Активно используется в строй материалах, в металлургии, при повышении термических свойств стали.
					</div>
				</div>
			</div>

			<div class="press_list_item">
				<div class="pli_date">25 июля</div>
				<div class="pli_cnt">
					<div class="pli_cat">Новость</div>
					<a class="pli_title" href="/">Запуск нового участка раработки: объем добычи вырастет в два раза (без фото)</a>
					<div class="pli_anonce">
						Химическое соединение с формулой MgO, белые кристаллы, нерастворимые в воде, пожаро- и взрывобезопасен. Основная форма — минерал периклаз. Активно используется в строй материалах, в металлургии, при повышении термических свойств стали.
					</div>
				</div>
			</div>

			<div class="press_list_item">
				<div class="pli_date">25 июля</div>
				<div class="pli_cnt">
					<div class="pli_cat">Новость</div>
					<a class="pli_title" href="/">Запуск нового участка раработки: объем добычи вырастет в два раза (без фото)</a>
					<div class="pli_anonce">
						Химическое соединение с формулой MgO, белые кристаллы, нерастворимые в воде, пожаро- и взрывобезопасен. Основная форма — минерал периклаз. Активно используется в строй материалах, в металлургии, при повышении термических свойств стали.
					</div>
				</div>
			</div>
		</div>
		<div class="load_more_news">Показать еще новости</div>
	</div>
</section>

<?php include 'footer.php'; ?>
