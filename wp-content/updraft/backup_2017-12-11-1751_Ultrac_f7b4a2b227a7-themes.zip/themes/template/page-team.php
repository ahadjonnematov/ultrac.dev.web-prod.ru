<?php
/**
Template Name: Команда
 */

include 'header.php'; ?>

<section class="team inner_page">
	<div class="center_cnt">
		<h1>Команда</h1>

		<div class="single_team">
			<h2>Руководство</h2>

			<div class="single_team_dudes">
				<div class="single_team_dude">
					<div class="single_team_dude_img" style="background-image: url(/wp-content/themes/template/img/team_dude.jpg);"></div>
					<div class="single_team_dude_name">Иван Константинопольский</div>
					<p>генеральный директор</p>
				</div>

				<div class="single_team_dude">
					<div class="single_team_dude_img" style="background-image: url(/wp-content/themes/template/img/team_dude.jpg);"></div>
					<div class="single_team_dude_name">Иван Константинопольский</div>
					<p>генеральный директор</p>
				</div>

				<div class="single_team_dude">
					<div class="single_team_dude_img" style="background-image: url(/wp-content/themes/template/img/team_dude.jpg);"></div>
					<div class="single_team_dude_name">Иван Константинопольский</div>
					<p>генеральный директор</p>
				</div>

				<div class="single_team_dude">
					<div class="single_team_dude_img" style="background-image: url(/wp-content/themes/template/img/team_dude.jpg);"></div>
					<div class="single_team_dude_name">Иван Константинопольский</div>
					<p>генеральный директор</p>
				</div>
				
				<div class="single_team_dude">
					<div class="single_team_dude_img" style="background-image: url(/wp-content/themes/template/img/team_dude.jpg);"></div>
					<div class="single_team_dude_name">Иван Константинопольский</div>
					<p>генеральный директор</p>
				</div>
			</div>
		</div>

		<div class="single_team">
			<h2>Отдел продаж</h2>

			<div class="single_team_dudes">
				<div class="single_team_dude">
					<div class="single_team_dude_img" style="background-image: url(/wp-content/themes/template/img/team_dude.jpg);"></div>
					<div class="single_team_dude_name">Иван Константинопольский</div>
					<p>генеральный директор</p>
				</div>

				<div class="single_team_dude">
					<div class="single_team_dude_img" style="background-image: url(/wp-content/themes/template/img/team_dude.jpg);"></div>
					<div class="single_team_dude_name">Иван Константинопольский</div>
					<p>генеральный директор</p>
				</div>

				<div class="single_team_dude">
					<div class="single_team_dude_img" style="background-image: url(/wp-content/themes/template/img/team_dude.jpg);"></div>
					<div class="single_team_dude_name">Иван Константинопольский</div>
					<p>генеральный директор</p>
				</div>

				<div class="single_team_dude">
					<div class="single_team_dude_img" style="background-image: url(/wp-content/themes/template/img/team_dude.jpg);"></div>
					<div class="single_team_dude_name">Иван Константинопольский</div>
					<p>генеральный директор</p>
				</div>
			</div>
		</div>
	</div>
</section>

<?php include 'footer.php'; ?>
